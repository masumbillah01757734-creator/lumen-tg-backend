const axios = require("axios");
const FormData = require("form-data");

const BOT_TOKEN = process.env.BOT_TOKEN;
const API_BASE = `https://api.telegram.org/bot${BOT_TOKEN}`;
const FILE_BASE = `https://api.telegram.org/file/bot${BOT_TOKEN}`;

const api = axios.create({ baseURL: API_BASE, timeout: 15000 });

async function call(method, payload) {
  try {
    const { data } = await api.post(`/${method}`, payload);
    return data.result;
  } catch (err) {
    const desc = err.response?.data?.description || err.message;
    throw new Error(`Telegram API [${method}] failed: ${desc}`);
  }
}

/** Same as call(), but posts multipart/form-data (used for uploading real file bytes) */
async function callWithFile(method, fields, fileField, fileBuffer, fileName) {
  try {
    const form = new FormData();
    Object.entries(fields).forEach(([key, value]) => {
      if (value !== undefined && value !== null) form.append(key, String(value));
    });
    form.append(fileField, fileBuffer, { filename: fileName || "file" });

    const { data } = await api.post(`/${method}`, form, {
      headers: form.getHeaders(),
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
      timeout: 60000,
    });
    return data.result;
  } catch (err) {
    const desc = err.response?.data?.description || err.message;
    throw new Error(`Telegram API [${method}] failed: ${desc}`);
  }
}

/** Send a plain text reply to a user's chat */
function sendTextMessage(chat_id, text) {
  return call("sendMessage", { chat_id, text, parse_mode: "HTML" });
}

/** Send admin-side media reply (rarely used, but supported for completeness) */
function sendPhoto(chat_id, file_id, caption) {
  return call("sendPhoto", { chat_id, photo: file_id, caption });
}
function sendDocument(chat_id, file_id, caption) {
  return call("sendDocument", { chat_id, document: file_id, caption });
}

/** Send a voice message by re-using a Telegram file_id (e.g. the fixed /start welcome voice) */
function sendVoice(chat_id, fileId, caption) {
  return call("sendVoice", { chat_id, voice: fileId, caption });
}

/** Send a video by re-using a previously-uploaded Telegram file_id */
function sendVideo(chat_id, fileId, caption) {
  return call("sendVideo", { chat_id, video: fileId, caption });
}

/** Send an audio track by re-using a previously-uploaded Telegram file_id */
function sendAudio(chat_id, fileId, caption) {
  return call("sendAudio", { chat_id, audio: fileId, caption });
}

/**
 * Generic "send by file_id" dispatcher for the four media types the Step-sequence
 * feature deals with. file_ids issued by our bot are valid for sending to any chat,
 * not just the chat they were first uploaded to — so once an item has been sent once
 * (see uploadPhoto/uploadVideo/etc below), every future run reuses this, no re-upload.
 */
function sendMediaByFileId(type, chat_id, fileId, caption) {
  switch (type) {
    case "photo":
      return sendPhoto(chat_id, fileId, caption);
    case "video":
      return sendVideo(chat_id, fileId, caption);
    case "audio":
      return sendAudio(chat_id, fileId, caption);
    case "document":
      return sendDocument(chat_id, fileId, caption);
    default:
      throw new Error(`sendMediaByFileId: unsupported type "${type}"`);
  }
}

/** Show "typing..." indicator to the Telegram user when admin is typing a reply */
function sendChatAction(chat_id, action = "typing") {
  return call("sendChatAction", { chat_id, action });
}

/**
 * Upload real file bytes from the dashboard (admin's computer) straight to a user's chat.
 * Telegram picks the returned file's own file_id/file_unique_id — we store that, never the bytes.
 */
function uploadPhoto(chat_id, buffer, fileName, caption) {
  return callWithFile("sendPhoto", { chat_id, caption }, "photo", buffer, fileName);
}
function uploadVideo(chat_id, buffer, fileName, caption) {
  return callWithFile("sendVideo", { chat_id, caption }, "video", buffer, fileName);
}
function uploadAudio(chat_id, buffer, fileName, caption) {
  return callWithFile("sendAudio", { chat_id, caption }, "audio", buffer, fileName);
}
function uploadVoice(chat_id, buffer, fileName, caption) {
  return callWithFile("sendVoice", { chat_id, caption }, "voice", buffer, fileName);
}
/** Used for everything else, including .zip and other archives — Telegram treats these as generic documents */
function uploadDocument(chat_id, buffer, fileName, caption) {
  return callWithFile("sendDocument", { chat_id, caption }, "document", buffer, fileName);
}

/** Generic "upload raw bytes" dispatcher counterpart to sendMediaByFileId, for first-time sends */
function uploadMediaBuffer(type, chat_id, buffer, fileName, caption) {
  switch (type) {
    case "photo":
      return uploadPhoto(chat_id, buffer, fileName, caption);
    case "video":
      return uploadVideo(chat_id, buffer, fileName, caption);
    case "audio":
      return uploadAudio(chat_id, buffer, fileName, caption);
    case "document":
      return uploadDocument(chat_id, buffer, fileName, caption);
    default:
      throw new Error(`uploadMediaBuffer: unsupported type "${type}"`);
  }
}

/**
 * Re-sends a message (any type) from one chat straight into another chat, via Telegram's
 * copyMessage — unlike forwardMessage, this does NOT tag it "Forwarded from …", so the
 * original sender's identity never appears to the recipient.
 */
function copyMessage(toChatId, fromChatId, messageId) {
  return call("copyMessage", { chat_id: toChatId, from_chat_id: fromChatId, message_id: messageId });
}

/**
 * Resolve a Telegram file_id into a temporary direct file URL.
 * IMPORTANT: We never persist the file anywhere — this is fetched live,
 * on demand, whenever the dashboard needs to display/download it.
 */
async function resolveFileUrl(file_id) {
  const file = await call("getFile", { file_id });
  return `${FILE_BASE}/${file.file_path}`;
}

/** Fetch the user's current profile photo file_id (biggest available size) */
async function getUserProfilePhotoFileId(chat_id) {
  const result = await call("getUserProfilePhotos", { user_id: chat_id, limit: 1 });
  const photos = result?.photos?.[0];
  if (!photos || photos.length === 0) return null;
  return photos[photos.length - 1].file_id; // largest size
}

async function setWebhook(url, secretToken) {
  return call("setWebhook", {
    url,
    secret_token: secretToken,
    allowed_updates: ["message", "edited_message"],
  });
}

async function deleteWebhook() {
  return call("deleteWebhook", {});
}

module.exports = {
  sendTextMessage,
  sendPhoto,
  sendDocument,
  sendChatAction,
  sendVoice,
  sendVideo,
  sendAudio,
  sendMediaByFileId,
  uploadPhoto,
  uploadVideo,
  uploadAudio,
  uploadVoice,
  uploadDocument,
  uploadMediaBuffer,
  copyMessage,
  resolveFileUrl,
  getUserProfilePhotoFileId,
  setWebhook,
  deleteWebhook,
};
